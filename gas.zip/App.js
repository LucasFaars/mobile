import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { StyleSheet, Text, View, Image, TextInput, TouchableOpacity, Alert } from 'react-native';

export default function App() {
  const [alcool, setAlcool] = useState('');
  const [gasolina, setGasolina] = useState('');
  
  const validar = (text, setter) => {
    const regex = /^\d+(\.\d+)?$/;
    if (regex.test(text) || text === ''){setter(text);}
    else{Alert.alert("Entrada inválida, favor digitar apenas numeros.");}
  }

  const Calcular = () =>{
    if (alcool && gasolina){
      const precoAlcool = parseFloat(alcool);
      const precoGasolina = parseFloat(gasolina);
      
      var result = precoAlcool / precoGasolina;

      if (precoAlcool <= 0 && precoGasolina <= 0){
        Alert.alert('Não existe almoço grátis, valor não pode ser zero.');
      }else if(result < 0.7){
        Alert.alert("Alcool é a melhor opção!");
      }else if(result >= 0.7){
        Alert.alert("Gasolina é a melhor opção")
      }
    
    }else {Alert.alert("Favor preencher ambos os campos");}

  };

  return (
    <View style={styles.container}>
      <Image source={require("./assets/gas-pump.png")} style={styles.mage}/>
      <Text style={styles.h1}>Qual a melhor opção?</Text>
      <Text style={styles.text}>Álcool (preço por litro): </Text>
      <TextInput style={styles.input} placeholder='Ex: 6.58' keyboardType='numeric' onChangeText={(text)=>validar(text,setAlcool)}/>
      <Text style={styles.text}>Gasolina (preço por litro): </Text>
      <TextInput style={styles.input} placeholder='Ex: 4.71' keyboardType='numeric' onChangeText={(text)=>validar(text,setGasolina)}/>
      <TouchableOpacity style={styles.calc} onPress={Calcular}>
        <Text style={{margin:8,textAlign:'center', fontWeight:"bold"}}>Calcular</Text>
      </TouchableOpacity>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  
  container: {
    flex: 1,
    flexDirection:'column',
    backgroundColor: '#242424ff',
    alignItems: 'center',
    justifyContent: 'center',
    padding:20,
  },

  text: {
    color:'white',
    marginBottom:15
  },

  h1:{
    color:'white',
    fontSize:32,
    fontWeight:"bold",
    textAlign:'center',
    marginBottom:20,
    marginTop:20,
  },

  mage: {
    width: 200,
    height: 200,
    marginTop: 10
  },

  input: { 
    color:'black',
    backgroundColor:'white',
    width: '70%',
    height: "4%",
    borderRadius:3,
    //borderColor:'gray',
    //borderWidth: 1,
    marginBottom:10,
    paddingHorizontal:10,
  },

  calc: {
    width:'70%',
    height:'4%',
    borderRadius:3,
    color:"black",
    backgroundColor:"yellow",
    marginTop:10,
  },

});
