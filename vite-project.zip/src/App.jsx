import './App.css';
import Imag from './components/imag.jsx';

function App() {
  return (
    <Imag />      
  );
}

export default App;
