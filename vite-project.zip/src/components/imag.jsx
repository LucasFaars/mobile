import gas from "/src/assets/gas-price.png";
import {useState} from "react";
import {calcular} from "/src/components/funcoes.jsx"

function Image() {

    // --> validacao de input, devido a isso coloquei as funcoes no mesmo elemento.

    const [valor, setAlcool] = useState('');
    const [valor2, setGasosa] = useState('');
    
    const handleAlcool = (event) => {
        const value = event.target.value;
        if (/^\d*\.?\d*$/.test(value)) {
            setAlcool(value);
        }
    };

    const handleGasosa = (event) => {
        const value2 = event.target.value;
        if (/^\d*\.?\d*$/.test(value2)) {
            setGasosa(value2);
        }
    };
    
    const handleCalcular = () =>{
        calcular(valor, valor2)
    };

    return (
        <div className="container">
            <img src={gas} alt="Gas" className="header-image" />
            <div className="input-container">
                <h2>Qual a melhor opção?</h2>
                <label className="input-label">Álcool (Preço por litro)</label>
                <input type="text" placeholder="Ex: 3.52" className="input-field" value={valor} onChange={handleAlcool} />
                <label className="input-label">Gasolina (Preço por litro)</label>
                <input type="text" placeholder="Ex: 4.68" className="input-field" value={valor2} onChange={handleGasosa}/>
                <button className="calculate-button" onClick={handleCalcular}>Calcular</button>
            </div>
        </div>
    );
}

export default Image; // --> Export the correct function name
