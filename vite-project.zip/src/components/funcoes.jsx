
// --> regra de negocio feita de acordo com o solicitado pelo cliente. Todavia, a regra de negocio consta com erro matemático.
// --> ao colocar alcool = 4 e gasolina = 5 o resultado é 0.8, sendo maior que 0.7 e apresentando

export const calcular = (valor, valor2) => {
    const precoAlcool = parseFloat(valor);
    const precoGasolina = parseFloat(valor2);
    
    if (precoGasolina == 0 || precoAlcool == 0){
        alert('Não existe almoço grátis, nenhum valor pode ser zero.');
    };

    if (precoGasolina !== 0 && precoAlcool !== 0) {
        const resultado = precoAlcool / precoGasolina;
        if (resultado < 0.7) {
            alert(`Melhor abastecer com gasolina, resultado: ${resultado.toFixed(2)}! `);
        } else if (resultado >= 0.7) {
            alert(`Melhor abastecer com gasolina, resultado: ${resultado.toFixed(2)}! `);
        } else {
            alert("Algum erro aconteceu no cálculo, favor tentar novamente.");
        }
    };
};